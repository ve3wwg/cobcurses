#!/bin/sh

exec ./dotest 001

# End
