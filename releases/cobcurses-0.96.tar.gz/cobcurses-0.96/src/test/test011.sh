#!/bin/sh

exec ./dotest 011

# End
