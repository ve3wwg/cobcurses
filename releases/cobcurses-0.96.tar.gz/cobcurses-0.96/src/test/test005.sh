#!/bin/sh

exec ./dotest 005

# End
