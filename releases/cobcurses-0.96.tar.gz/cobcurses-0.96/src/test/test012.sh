#!/bin/sh

exec ./dotest 012

# End
