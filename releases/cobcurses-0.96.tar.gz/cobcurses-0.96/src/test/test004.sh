#!/bin/sh

exec ./dotest 004

# End
