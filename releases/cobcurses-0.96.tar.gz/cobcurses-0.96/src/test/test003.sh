#!/bin/sh

exec ./dotest 003

# End
