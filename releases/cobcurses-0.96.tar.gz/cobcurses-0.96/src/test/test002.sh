#!/bin/sh

exec ./dotest 002

# End
