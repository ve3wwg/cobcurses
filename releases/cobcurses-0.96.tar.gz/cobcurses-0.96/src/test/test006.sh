#!/bin/sh

exec ./dotest 006

# End
