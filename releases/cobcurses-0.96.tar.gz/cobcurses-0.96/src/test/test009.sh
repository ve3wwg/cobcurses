#!/bin/sh

exec ./dotest 009

# End
