#!/bin/sh

exec ./dotest 008

# End
