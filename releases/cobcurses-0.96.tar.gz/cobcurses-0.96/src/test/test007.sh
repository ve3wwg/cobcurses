#!/bin/sh

exec ./dotest 007

# End
